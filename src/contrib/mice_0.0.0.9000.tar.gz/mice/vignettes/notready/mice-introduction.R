## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(cache=TRUE)
library(Rcpp)

## ----evalCpp, eval=FALSE-------------------------------------------------
#  library("Rcpp")
#  evalCpp("2 + 2")

