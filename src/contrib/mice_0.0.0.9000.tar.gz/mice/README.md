# mice
Yet another Model of Intermediate Complexity for Ecosystem assessment
