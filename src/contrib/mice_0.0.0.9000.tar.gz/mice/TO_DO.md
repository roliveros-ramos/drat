
- accessibility for functional groups
- several recruitment models
- several growth models
- seeding?
- lower than 1 equals 0

- classes for input data: groups and fleets
- methods for input data

- classes for simulation

- restart

